# HSMUpgradeTest 升级流程分析与流程图

> 代码基线:`main` @ `95a0a80`(含 `37ed265` 「Modify the download process. Add the processing of the test state.」)
> 主要文件:`hsm_upgrade_test.c`(816 行)、`scrpit_deal.c`、`hsm_logic_level.c`、`hsm_hardware_level.c`、`spidev_test.c`
> 图:Mermaid(GitHub / VS Code / Typora 可直接渲染),另附 ASCII 骨架便于终端阅读。

---

## 1. 入口与调用链

`HSMUpgradeTest()` 是整条升级流程的**唯一编排函数**,由 `main()` 在命令行传入 **6 个参数**时调用。

```c
./HSM_UPGRADE-TOOL_test /dev/spidev32766.0 98 96 DownloadFile1901.ini 1000000
//        argv[0]          argv[1](SPI)  argv[2](busy) argv[3](reset) argv[4](FW ini) argv[5](SPI clk)
```

| 参数 | 用途 | 落点 |
|---|---|---|
| argv[1] | SPI 设备节点 | `SPI_DEV_NAME`(`spidev_test.c:90`) |
| argv[2] | BUSY 引脚号 | `busy`(`hsm_upgrade_test.c:545`) |
| argv[3] | RESET 引脚号 | `reset`(`hsm_upgrade_test.c:546`) |
| argv[4] | 固件 ini 脚本 | `script_analysis_for_bootloader(argv[4],1)`(`:799`) |
| argv[5] | SPI 频率 | `spi_frequency`(`:547`),必须 `500000 < f < 20000000`,否则 `return 5` |

```mermaid
graph TD
    MAIN["main() spidev_test.c:78"] -->|"argc == 6"| HUT["HSMUpgradeTest() hsm_upgrade_test.c:537"]
    MAIN -->|"argc == 2"| TEST["各类测试例程 hsm_test_task.c"]
    HUT --> HWI["HSMHardwareInit() 信号量/线程锁"]
    HUT --> FPI["FunctionPointerInit() 逻辑层函数指针表"]
    HUT -->|"STEP1"| SYNC["ISTECC512A_StatusSync / CosVersionRead"]
    HUT -->|"STEP2"| SA["script_analysis HSM_BOOTLOADER.ini"]
    HUT -->|"STEP2 前置"| RFC["ReadFactoryCodeState()"]
    RFC -.->|"state == 02"| TMP["HSMTestModeProcess()"]
    HUT -->|"STEP3"| ERASE["Pin confirm + ISTECC512A_APPErase"]
    HUT -->|"STEP4"| SAB["script_analysis_for_bootloader argv[4]"]
    SA --> RX["receive_script_respond()"]
    SAB --> RX2["ReceiveOneMessage()"]
    RX --> LOW["ISTECC512A_Send/ReceiveOneMessage"]
    RX2 --> LOW
    LOW --> HW["HSMWrite / HSMRead → ioctl SPI_IOC_MESSAGE(1)"]
```

### 报文格式速查

| 方向 | 格式 |
|---|---|
| 主机→芯片(封装帧) | `40 42 53 55` + 长度(4B 小端) + 裸 APDU + XOR 校验(共 +9 字节,`usb_format_to_spi_format` `scrpit_deal.c:160`) |
| 芯片→主机(封装帧) | 帧头 `50 42 53 55` + 长度(4B) + 数据 + XOR |
| 芯片状态/错误横幅 | `63 62 63 65`("cbce",表示芯片处于状态报告,不跟随数据) |
| 裸 APDU(bootloader / COS 升级模式) | `BF <INS> <…>` ,无 `40 42 53 55` 封装 |
| 分包粒度 | 固定 **16 字节/包**,一次 `ioctl` 传输一包 |

---

## 2. 顶层主流程图

`step` 变量是唯一的流程指针:`0x01` 检查状态 → `0x02` 下载 bootloader → `0x03` 擦除固件 → `0x04` 下载固件。
注意:**四个 `if` 是顺序串接而非 `switch`**,STEP3 可以改写 `step` 后再落入下面的 STEP2/STEP4 块。

```mermaid
flowchart TD
    START(["HSMUpgradeTest(argc, argv)"]) --> PARSE["读取 argv[2] busy / argv[3] reset / argv[5] spi_frequency"]
    PARSE --> CHK{"spi_frequency 不在 0.5M ~ 20M 区间 ?"}
    CHK -->|"是"| RET5["return 5:参数错误"]
    CHK -->|"否"| INIT["print_upgrade_message()<br/>HSMHardwareInit(spi_frequency)<br/>FunctionPointerInit"]
    INIT --> S1["STEP1 · step = STEP1_CHECK_STATUS 0x01"]

    S1 --> SYNC["STEP1 · ISTECC512A_StatusSync"]
    SYNC --> SYNCR{"返回 != 0 ?"}
    SYNCR -->|"是:同步失败"| NOTE1["判定:既无 bootloader 也无 firmware<br/>step = STEP2 0x02"]
    SYNCR -->|"否"| VER["STEP1 · ISTECC512A_CosVersionRead(version)"]
    VER --> CMP{"memcmp(version+3, 'spiloader', 9)"}
    CMP -->|"!= 0:当前是 firmware"| NOTE2["step = STEP3 0x03"]
    CMP -->|"== 0:已有 bootloader"| NOTE3["step = STEP4 0x04"]

    NOTE1 --> LOCK["HSMSetPMutexAndSemphre<br/>pthread mutex + SysV 信号量 P 操作<br/>锁死整个擦除/下载过程"]
    NOTE2 --> LOCK
    NOTE3 --> LOCK

    LOCK --> D2{"step == STEP2 ?"}
    D2 -->|"是"| HB["STEP2 · 握手:最多 10 次 ReceiveOneMessage,16B<br/>每次延时 20ms,等待 temp[0..3] == 63 62 63 65"]
    HB --> HBOK{"10 次内收到 cbce ?"}
    HBOK -->|"否"| RET1A["return 0x01 DOWNLOAD_BOOTLOADER_FAILED<br/>⚠ 未解锁、未 Deinit"]
    HBOK -->|"是"| HB2["再收 1 包 16B + 20ms<br/>延时 100ms"]
    HB2 --> RFC["ReadFactoryCodeState"]
    RFC --> RFCOK{"读取成功?"}
    RFCOK -->|"否"| ERR1["解锁 + Deinit → return 0x01"]
    RFCOK -->|"是"| DSTATE{"state 值"}
    DSTATE -->|"02 测试态"| TMP["HSMTestModeProcess"]
    TMP --> TMPR{"成功?"}
    TMPR -->|"否"| ERR1B["解锁 + Deinit → return 0x01"]
    TMPR -->|"是"| HALT["打印 10 次 PLEASE MAKE SURE RESET THE HSM MODULE!<br/>每次 1s → while(1) 停等人工复位"]
    DSTATE -->|"03 / 04 / 05 下载态"| SKIP["打印 SKIP TEST MODE PROCESS"]
    DSTATE -->|"其他"| HALT2["打印 NOT IN TEST MODE OR DOWNLOAD MODE<br/>→ while(1) 停等人工介入"]
    SKIP --> BL["script_analysis, HSM_BOOTLOADER.ini"]
    BL --> BLR{"返回 != 0 ?"}
    BLR -->|"是"| ERR1C["解锁 + Deinit → return 0x01"]
    BLR -->|"否"| TO4["step = STEP4 0x04"]

    D2 -->|"否"| D3{"step == STEP3 ?"}
    D3 -->|"是"| PIN["STEP3 · SendOneMessageOneShot(default_pin, 14)<br/>BF 0C 0E 00 00 00 + 01..08<br/>延时 100ms → ReceiveOneMessage,16B"]
    PIN --> PINOK{"ret == 0 且 temp[0..1] == 90 00 ?"}
    PINOK -->|"否"| ERR3["解锁 + Deinit → return 0x02 ERASE_FIRMWARE_FAILED"]
    PINOK -->|"是"| AP["STEP3 · ISTECC512A_APPErase"]
    AP --> APOK{"返回 != 0 ?"}
    APOK -->|"是"| ERR3B["解锁 + Deinit → return 0x02"]
    APOK -->|"否"| POLL["轮询最多 10 次 ReceiveOneMessage,16B + 20ms"]
    POLL --> POK{"回读横幅判定"}
    POK -->|"temp[0..3] == 63 62 63 65"| RB["再收 1 包 → step = STEP2 0x02"]
    POK -->|"temp[0..1] == 6E 00"| RF["step = STEP4 0x04"]
    POK -->|"10 次都不匹配"| RN["step 保持 0x03,继续向下"]

    D3 -->|"否"| D4{"step == STEP4 ?"}
    RB --> D2B{"step == STEP2 ? 第二次判定块"}
    D2B -->|"是"| BL2["延时 100ms → script_analysis, HSM_BOOTLOADER.ini<br/>⚠ 此处不再检查出厂码状态"]
    BL2 --> BL2R{"返回 != 0 ?"}
    BL2R -->|"是"| ERR2["解锁 + Deinit → return 0x01"]
    BL2R -->|"否"| TO4B["step = STEP4 0x04"]
    D2B -->|"否"| D4
    TO4 --> D4
    TO4B --> D4
    RF --> D4
    RN --> D4

    D4 -->|"是"| FW["STEP4 · 延时 100ms<br/>script_analysis_for_bootloader(argv[4], 1)<br/>延时 100ms"]
    FW --> FWR{"返回 != 0 ?"}
    FWR -->|"是"| ERR4["解锁 + Deinit → return 0x03 DOWNLOAD_FIRMWARE_FAILED"]
    FWR -->|"否"| OK["解锁 + Deinit<br/>return 0x00 UPGRADE_SUCCESS"]
    D4 -->|"否:理论路径"| HOLE["函数体末尾缺少 return,返回值未定义"]
```

### ASCII 骨架

```
参数校验(f 必须在 0.5M~20M 之间,否则 return 5)
   └─ HSMHardwareInit + FunctionPointerInit
        └─ STEP1: StatusSync()
             ├─ 失败 ───────────────────────────► step = STEP2(无 bootloader 无固件)
             └─ 成功 → CosVersionRead()
                   ├─ version[3..] != "spiloader" ► step = STEP3(有固件,需擦除)
                   └─ version[3..] == "spiloader" ► step = STEP4(只有 bootloader)
        └─ 🔒 HSMSetPMutexAndSemphre()  ← 从此处到结束全程独占
        └─ if STEP2: 等 "cbce" 横幅(≤10×20ms)
             ├─ 超时 → return 0x01(⚠ 泄漏锁)
             └─ OK → ReadFactoryCodeState()
                   ├─ 02 → HSMTestModeProcess() → 成功 → 🛑 while(1) 等人工复位后重跑
                   ├─ 03/04/05 → 继续
                   └─ 其他 → 🛑 while(1)
             → script_analysis("HSM_BOOTLOADER.ini") → step = STEP4
        └─ if STEP3: PIN 校验(90 00) → APPErase() → 轮询横幅
             ├─ "cbce" → step = STEP2(跳过出厂码检查的第二个 STEP2 块)
             └─ "6E 00" → step = STEP4
        └─ if STEP4: script_analysis_for_bootloader(argv[4]) → 🔓 → return 0x00 / 0x03
```

### STEP3 的 PIN 报文说明

`default_pin[] = {BF, 0C, 0E 00, 00, 00, 01 02 03 04 05 06 07 08}`,按逻辑层头部约定
`BF | INS | Lc(2B 小端) | index | 保留 | 数据`,`Lc = 0x000E = 14`(含 6 字节头),口令即 1..8 这 8 个字节值。
它手写常量走 `SendOneMessageOneShot`,与逻辑层里会自动加锁的 `PinConfirm()`(`hsm_logic_level.c:948`)构造出的报文等价 —— 因为此处必须复用调用方已持有的升级锁。

---

## 3. `step` 状态机

```mermaid
stateDiagram-v2
    [*] --> STEP1_CHECK_STATUS: HSMHardwareInit 完成
    STEP1_CHECK_STATUS --> STEP2_DOWNLOAD_BOOTLOADER: StatusSync 失败
    STEP1_CHECK_STATUS --> STEP3_ERASE_HSM_FW: 有固件(version 无 spiloader)
    STEP1_CHECK_STATUS --> STEP4_DOWNLOAD_FW: 只有 bootloader(version 含 spiloader)
    STEP2_DOWNLOAD_BOOTLOADER --> STEP4_DOWNLOAD_FW: bootloader 下载成功
    STEP2_DOWNLOAD_BOOTLOADER --> FAIL_01: 握手超时 / 出厂码读失败 / 测试态处理失败 / 下载失败
    STEP3_ERASE_HSM_FW --> STEP2_DOWNLOAD_BOOTLOADER: 擦除后收到 cbce(需重装 bootloader)
    STEP3_ERASE_HSM_FW --> STEP4_DOWNLOAD_FW: 擦除后收到 6E 00(bootloader 已在)
    STEP3_ERASE_HSM_FW --> FAIL_02: PIN 校验失败 / APPErase 失败
    STEP4_DOWNLOAD_FW --> SUCCESS: return 0x00 UPGRADE_SUCCESS
    STEP4_DOWNLOAD_FW --> FAIL_03: return 0x03 DOWNLOAD_FIRMWARE_FAILED
    SUCCESS --> [*]
    FAIL_01 --> [*]
    FAIL_02 --> [*]
    FAIL_03 --> [*]
    note right of STEP2_DOWNLOAD_BOOTLOADER
        02 测试态分支:HSMTestModeProcess 成功后
        停在 while(1),需人工复位并重跑工具
    end note
```

四种典型场景(对应 README `verison 1.9.0.1(01)`):

| 芯片当前状态 | 路径 | 结果 |
|---|---|---|
| 空片(无 bootloader 无固件) | STEP1 → STEP2 → STEP4 | 先下 bootloader,再下固件 |
| 只有 bootloader | STEP1 → STEP4 | 直接下固件,**保留 SM2 密钥** |
| 只有旧固件 | STEP1 → STEP3 → (STEP2) → STEP4 | 擦除 → 视横幅决定是否补 bootloader → 下固件 |
| bootloader + 固件 | STEP1 → STEP3 → STEP4 | 擦除固件 → 经 bootloader 下新固件 |
| 测试态 02 | STEP1 → STEP2 → ReadFactoryCodeState → HSMTestModeProcess → 🛑停等 | 需人工复位后重跑 |

---

## 4. 子流程:`ReadFactoryCodeState()`

`hsm_upgrade_test.c:145`。读取出厂码(BF48)以拿到芯片 ROM boot 状态字节 `02/03/04/05`,是决定是否要走测试态处理的前置判断。

```mermaid
flowchart TD
    A(["ReadFactoryCodeState(pFunc, *state)"]) --> B["清缓冲:dummy[16]=00, receive_data[32]=00"]
    B --> C["SendOneMessage(spiReadFactoryCmd, 16)<br/>40 42 53 55 · 0E 00 00 00 · BF 48 00 00 12 EF · FF FF"]
    C --> C1{"发送返回非 0 ?"}
    C1 -->|是| E1["print SEND CMD 失败 → return 0x01"]
    C1 -->|否| D["HSMMsDelay(5)"]
    D --> F["ReceiveOneMessage(dummy, 16) 丢弃"]
    F --> F1{"失败?"}
    F1 -->|是| E2["print RECEIVE DUMMY 失败 → return 0x01"]
    F1 -->|否| G["HSMMsDelay(5)"]
    G --> H["循环 2 包:ReceiveOneMessage(receive_data + i*16, 16)<br/>每包后 HSMMsDelay(5)"]
    H --> H1{"任一包失败?"}
    H1 -->|是| E3["return 0x01"]
    H1 -->|否| I["hex_dump(receive_data, 32)"]
    I --> J{"帧头 == 50 42 53 55 ?"}
    J -->|否| E4["WRONG RESPOND HEADER → return 0x01<br/>(非 ROM boot 态时 MISO 回读为 FF 垃圾数据)"]
    J -->|是| K["respond_len = rx[4] + rx[5] × 256"]
    K --> L{"respond_len 不小于 26 ?"}
    L -->|否| E5["WRONG RESPOND LEN → return 0x01"]
    L -->|是| M["state = receive_data[25]<br/>print FACTORY CODE STATE"]
    M --> N(["return 0x00 READ_FACTORY_CODE_SUCCESS"])
```

* SPI 时序全部为**固定延时**(非 BUSY 等待),`FACTORY_CODE_DELAY_MS = 5`。
* 状态字节偏移固定在 `receive_data[25]`(`FACTORY_CODE_STATE_INDEX`),响应缓冲区开 32 字节。

---

## 5. 子流程:`HSMTestModeProcess()`(02 测试态)

`hsm_upgrade_test.c:376`,对应 MCU 端 02 态分支:认证 → FT 进入 → 退出测试态 → **硬复位**。

```mermaid
sequenceDiagram
    participant T as HSMTestModeProcess
    participant X as TestModeExchange
    participant H as HSM (IS32U512A)

    Note over T: 入口条件:出厂码状态 == 02(由调用方判定)
    T->>X: test_1 认证 BF 45 (32B 缓冲, 2 包)
    X->>H: 逐包 SendOneMessage 16B(包间 5ms)
    X->>H: 等 10ms → Receive dummy 16B → 等 10ms → Receive respond 16B
    H-->>T: respond[8..9] 必须 == 90 00,否则 FAILED(test_1)
    T->>X: test_2 进入 FT BF EE 01 0F 02 57 (16B, 1 包)
    X->>H: 发包 → 等 5000ms → dummy → 等 60ms → respond
    H-->>T: respond[8..11] 必须 == 0F 0F 90 00,否则 FAILED(test_2)
    T->>X: test_3 退出测试态 BF EE 55 88 00 86 (16B, 1 包)
    X->>H: 发包 → 等 10ms → dummy → 等 10ms → respond
    H-->>T: respond[8..9] 必须 == 90 00,否则 FAILED(test_3)
    T->>H: HSMReset() 硬复位(RESET 低 10ms → 高 10ms)
    T->>T: HSMMsDelay(1000)
    T->>H: ReadFactoryCodeState()
    H-->>T: state 必须为 03/04/05(IsDownloadState),否则 FAILED
    Note over T: TEST_MODE_INCLUDE_DOWNLOAD == 0<br/>其后的下载+二次确认代码被编译屏蔽
```

`TestModeExchange()` 通用交换原语(`hsm_upgrade_test.c:275`):

```mermaid
flowchart TD
    A(["TestModeExchange(cmd, cmd_buf_len, send_delay, recv_delay)"]) --> B{"cmd_buf_len mod 16 == 0 ?"}
    B -->|否| E0["INVALID COMMAND LENGTH → return 0x01"]
    B -->|是| C["offset = 0"]
    C --> D["SendOneMessage(cmd + offset, 16)"]
    D --> D1{"失败?"}
    D1 -->|是| E1["SEND COMMAND FAILED → return 0x01"]
    D1 -->|否| F["HSMMsDelay(5) 固定包间延时"]
    F --> G{"还有下一包?"}
    G -->|是| D
    G -->|否| H["HSMMsDelay(send_delay_ms)"]
    H --> I["ReceiveOneMessage(dummy, 16)"]
    I --> I1{"失败?"}
    I1 -->|是| E2["RECEIVE DUMMY FAILED → return 0x01"]
    I1 -->|否| J["HSMMsDelay(recv_delay_ms)"]
    J --> K["ReceiveOneMessage(respond, 16)"]
    K --> K1{"失败?"}
    K1 -->|是| E3["RECEIVE RESPOND FAILED → return 0x01"]
    K1 -->|否| L["hex_dump(respond, 16)"]
    L --> M(["return 0x00 SUCCESS(状态字由调用方校验)"])
```

> ⚠ 三条命令的校验在 `TestModeExchange` **之外**做,只比对 `respond[8..]`,不校验帧头 `50 42 53 55` 和长度字段(与 `ReadFactoryCodeState` 不同)。

---

## 6. 子流程:`script_analysis()`(下载 BOOTLOADER)

`scrpit_deal.c:649`,逐行读 `APDU=<hex>,0x9000` 脚本;发送带 `40 42 53 55` 封装的命令。

```mermaid
flowchart TD
    A(["script_analysis(file_name, comapre_en=1)"]) --> B["FunctionPointerInit(ptr)<br/>line/send/receive/compare 各 1024B"]
    B --> C{"fopen 成功?"}
    C -->|否| R1["return 1"]
    C -->|是| D["gettimeofday 起点, i = 0<br/>cod_guide = 40 42 53 55 0E 00 00 00 BF 49 00 00 00 FC"]
    D --> E{"fgets 还有一行?"}
    E -->|否| K["打印耗时与总行数"]
    K --> L["send_script_cmd(cod_guide,12) 引导 HSM 启动<br/>HSMMsDelay(60)"]
    L --> M["fclose → return 0"]
    E -->|是| N["analysis_one_line_script(line, send, send_len, compare, compare_len)<br/>拆 ',' → 十六进制转字节 → usb_format_to_spi_format 加封装(send_len += 9)"]
    N --> O["send_script_cmd → ISTECC512A_SendOneMessage<br/>按 16B 分包发送(⚠ 返回值被忽略)"]
    O --> P["HSMUsDelay(5)"]
    P --> Q["receive_script_respond(receive, 1024, ptr)"]
    Q --> Q1{"ret != 0 ?"}
    Q1 -->|是| R2["print RECEIVE ... ERROR:ret, LINE i, STOP<br/>fclose → return ret"]
    Q1 -->|否| S{"comapre_en ?"}
    S -->|否| U["i++, 清 line"]
    S -->|是| V["compare_respond_value(receive, compare)<br/>先验 XOR,再验整帧(len==9)或尾 2 字节 SW"]
    V --> V1{"匹配?"}
    V1 -->|否| W["print WRONG RESPOND + hex_dump<br/>❌ exit(1) 直接终止进程(不 fclose、不解锁)"]
    V1 -->|是| U
    U --> E
```

`receive_script_respond()`(`scrpit_deal.c:479`)——响应接收与超时:

```mermaid
flowchart TD
    A(["receive_script_respond(receive, buf_len, p)"]) --> B["time_out_count = 6*10 = 60 次轮询"]
    B --> C["ReceiveOneMessage(receive, 16)"]
    C --> D{"轮询次数 time 大于 3 ?"}
    D -->|是| D1["HSMMsDelay(500)"]
    D -->|否| D2["HSMMsDelay(2)"]
    D1 --> E{"帧头判定"}
    D2 --> E
    E -->|"50 42 53 55"| F["收到正确响应,跳出轮询"]
    E -->|"63 62 63 65"| G(["ret = 1,立即 return(芯片报错/状态横幅)"])
    E -->|"其他(00 00 …)"| H{"time 未到 60 次 ?"}
    H -->|是| C
    H -->|否| I["time 到达 60 → 超时<br/>ret = 2,立即 return(不再解析垃圾长度字段)"]
    F --> J["len = receive[4] + receive[5] × 256<br/>packets = (len + 15) / 16"]
    J --> K{"packets × 16 超出 buf_len ?"}
    K -->|是| L["ret = 4 缓冲区溢出保护,return"]
    K -->|否| M{"len == 0 ?"}
    M -->|是| N["ret = 3"]
    M -->|否| O{"packets 大于 1 ?"}
    O -->|"while(packets--) 续读"| P["ReceiveOneMessage(receive[16*i],16) + 1us"]
    P --> Q(["ret = 0"])
    O -->|否| Q
```

返回值语义:

| 值 | 含义 |
|---|---|
| 0 | 全部行执行完毕且比对通过 |
| 1 | `fopen` 失败 **或** 芯片回 `63 62 63 65` |
| 2 | 轮询 60 次仍无正确帧头(实测最坏 ≈ 4×2ms + 56×500ms ≈ **28s**,注释里的 230ms 已过时) |
| 3 | 响应长度字段为 0 |
| 4 | 响应长度超过调用方缓冲区 |
| — | 比对失败:`exit(1)`,不返回给调用方 |

---

## 7. 子流程:`script_analysis_for_bootloader()`(经 bootloader 下载固件)

`scrpit_deal.c:737`。与 `script_analysis` 的关键差别:**发裸 APDU、一次整包写完、收包极简、激活命令不读取响应**。

```mermaid
flowchart TD
    A(["script_analysis_for_bootloader(argv[4], comapre_en=1)"]) --> B["FunctionPointerInit(ptr)<br/>line/send/receive/compare 各 2048B"]
    B --> C{"fopen 成功?"}
    C -->|否| R1["return 1(本函数唯一的非 0 返回路径)"]
    C -->|是| E{"fgets 还有一行?"}
    E -->|否| Z["打印耗时/行数 → fclose → return 0"]
    E -->|是| N["analysis_one_line_script_for_bootloader<br/>拆 ',' → 十六进制转字节 → 裸 APDU(不加 SPI 封装)"]
    N --> O["ISTECC512A_SendOneMessageOneShot(send, send_len)<br/>整块一次性 HSMWrite(不分 16B 包,返回值恒为 0)"]
    O --> P{"i == 1 ?"}
    P -->|是| P1["HSMMsDelay(500) 第二条命令后长延时"]
    P -->|否| P2["HSMMsDelay(10)"]
    P1 --> Q{"send[1] != 0x46 ?"}
    P2 --> Q
    Q -->|"否:BF46 生效 COS"| U["不接收、不比较"]
    Q -->|是| R["ReceiveOneMessage(receive, 16) 单包读<br/>(无帧头轮询、无超时、无续包)"]
    R --> S{"comapre_en 且 send[1] != 0x46 ?"}
    S -->|是| T{"memcmp(receive, compare, 2) == 0 ?"}
    T -->|否| W["print WRONG RESPOND<br/>❌ exit(1) 终止进程"]
    T -->|是| T1["print COMPARE SUCCESS"]
    S -->|否| U
    T1 --> U
    U --> X["i++, 清 line/send, 打印 CURRENT LINE"]
    X --> E
```

* `send[1]` 是裸 APDU 的 INS 字节。`0x46`(BF46)= 生效/激活 COS,**不接收也不比对**,其余行按首 2 字节比对 `90 00`。
* 以仓库内脚本实测:`UpgradeFile/DownloadFile1901.ini` 共 34 行 = `BF45`×1(认证)+ `BF44`×1 + `BF40`×31(数据块,单行最大 518 字节)+ `BF46`×1(生效)。
* `UpgradeFile/HSM_BOOTLOADER.ini` 共 51 行走 `script_analysis`:`BF45`×1、`bf44`×1、`bf46 55AA00`×1、`BF40`×45、`BF42`×2、`bf46 010100`×1(最后一条生效命令),单行最大 138 字节(封装后 +9)。

---

## 8. 延时与时序参数汇总

| 位置 | 宏/参数 | 值 | 说明 |
|---|---|---|---|
| 出厂码读 | `FACTORY_CODE_DELAY_MS` | 5ms | 命令后、dummy 后、每响应包后 |
| 测试态包间 | `TestModeExchange` 内 `HSMMsDelay(5)` | 5ms | 每个 16B 发送包之后(硬编码) |
| test_1 认证 | `TEST_MODE_DELAY_AFTER_CMD1_MS` / `DUMMY1` | 10 / 10 ms | |
| test_2 进 FT | `TEST_MODE_DELAY_AFTER_CMD2_MS` / `DUMMY2` | 5000 / 60 ms | FT 流程耗时最长 |
| test_3 退出测试态 | `TEST_MODE_DELAY_AFTER_CMD3_MS` / `DUMMY3` | 10 / 10 ms | |
| 复位后等待 | `TEST_MODE_RESET_WAIT_MS` | 1000 ms | `HSMReset()` 之后 |
| 分包延时 | `IS32U512ASendOneMessage` / `ReceiveOneMessage` | 2ms / 1ms 每包 | `hsm_logic_level.c:2212/2254` |
| STEP2 握手 | 10 × 20ms | 200ms | 等 `cbce` 横幅 |
| STEP3 轮询 | 10 × 20ms | 200ms | 判 `cbce` / `6E 00` |
| 脚本接收 | 4×2ms + 56×500ms | ≈28s 最坏 | `receive_script_respond` |
| bootloader 脚本 | 每条命令后 `HSMUsDelay(5)` | | |
| 固件脚本 | 第 2 行后 500ms,其余 10ms | | |
| 引导启动 | `cod_guide` 后 60ms | | 仅 `script_analysis` |

> 延时标定说明见 `hsm_upgrade_test.c:55-58`:MCU 端用忙等循环(约 30ns/次)计时,Linux 侧统一换算成 ms 固定延时,只需调这些宏。

---

## 9. 返回值一览

| 返回值 | 宏 | 触发条件 | 是否释放锁 |
|---|---|---|---|
| `0x00` | `UPGRADE_SUCCESS` | STEP4 固件下载成功 | ✅ |
| `0x01` | `DOWNLOAD_BOOTLOADER_FAILED` | STEP2 握手超时 / 出厂码读失败 / 测试态处理失败 / bootloader 下载失败 | ⚠ 握手超时那条路径**未释放** |
| `0x02` | `ERASE_FIRMWARE_FAILED` | PIN 校验失败 / `APPErase` 失败 | ✅ |
| `0x03` | `DOWNLOAD_FIRMWARE_FAILED` | 固件脚本下载失败 | ✅ |
| `5` | — | SPI 频率不在 0.5M~20M | —(此时尚未加锁) |
| 未定义 | — | 若 `step` 未命中任何块(理论上不发生),函数尾部无 `return` | — |

调用方 `main()` 忽略返回值,统一 `return 0`(`spidev_test.c:99-100`)。

---

## 10. 锁与资源生命周期

```mermaid
flowchart LR
    A["HSMHardwareInit()<br/>HSMSempohreInit + HardwareSempohreInit<br/>+ HSMThreadMutexInit + 首次置 1"] --> B["STEP1 检查<br/>(StatusSync/CosVersionRead 内部自带锁)"]
    B --> C["HSMSetPMutexAndSemphre()<br/>pthread_mutex_lock + semop(-1)"]
    C --> D["STEP2 / STEP3 / STEP4<br/>全程独占 Send/ReceiveOneMessage"]
    D --> E["HSMClearPMutexAndSemphre()<br/>semop(+1) + pthread_mutex_unlock"]
    E --> F["HSMHardwareDeinit() 当前是空实现"]
    D -.->|"while(1) 停等 / exit(1)"| X["🔒 锁永不释放"]
```

* `ISTECC512A_SendOneMessage / ReceiveOneMessage / SendOneMessageOneShot / APPErase` **自身不加锁**(部分锁调用被注释掉),依赖调用方持有的互斥锁 + 信号量,并共享静态 `tx_buff`。
* `HSMWrite/HSMRead` 每次调用都 `open`+`close` 一次 spidev(`verison 1.9.0.1(04)` 的改动)。
* `HSMGetBusystatus()` 目前恒返回 0(`hsm_hardware_level.c:592`),因此驱动里的 `while(HSMGetBusystatus());` 实际不产生流控,全靠固定延时。

---

## 11. 阅读流程图时需要注意的点

1. **两个 `while(1)` 停等点**(`hsm_upgrade_test.c:681`、`:697`):测试态处理成功后并不会自动继续下载,而是要求**人工复位模块并重跑工具**;未知出厂码状态同样死循环挂住。这是当前 02 态分支的设计行为,不是崩溃。
2. **第二个 STEP2 块没有出厂码状态闸门**:STEP3 擦除后若收到 `cbce` 会跳到 `:776` 的 bootloader 下载,不再检查 02 测试态。
3. **`exit(1)` 绕过清理**:脚本比对失败(`scrpit_deal.c:710`、`:797`)直接终止进程,互斥锁/信号量保持占用,同机其他进程后续会阻塞。
4. **锁泄漏路径**:`:616` 握手超时直接 `return`,未调用 `HSMClearPMutexAndSemphre()`。
5. **`#if TEST_MODE_INCLUDE_DOWNLOAD` 分支被关**(=`0`,`:476-494`):HSM-RESET 功能未确认前必须保持 0。
6. **`FunctionPointerInit` 未填满结构体**:`SM2ExportID`、`APPUpdate`、`SM2CompleteKDF`、`SM2EncryptSignKeyKDF` 保持未初始化,升级流程未用到,但不要调用。
7. **`SendOneMessage` 会按 16 字节向上对齐拷贝**(`hsm_logic_level.c:2209`),调用方缓冲区必须覆盖补齐后的长度——测试态命令缓冲区因此显式补 `0xFF` 到 16 的整数倍。
8. **`version[3..11]` 判定**:`CosVersionRead` 拷贝 14 字节原始数据、不以 `'\0'` 结尾,`memcmp(&version[3],"spiloader",9)` 依赖 `version[16]` 缓冲区长度。
9. **响应校验强度不一致**:`ReadFactoryCodeState` 校验帧头+长度;`TestModeExchange` 与 `script_analysis_for_bootloader` 只看固定偏移的状态字节。

---

## 12. 端到端时序(已有 bootloader、直接升级固件的成功路径)

```mermaid
sequenceDiagram
    autonumber
    participant U as 用户/上位机
    participant L as HSMUpgradeTest (Linux)
    participant P as HSM IS32U512A

    U->>L: ./tool /dev/spidev32766.0 98 96 DownloadFile1901.ini 1000000
    L->>L: HSMHardwareInit + FunctionPointerInit
    L->>P: StatusSync (BF FA 06 00 00 00 ×2 + 读 4B)
    P-->>L: 90 00 → 同步成功
    L->>P: CosVersionRead (BF 10 06 …)
    P-->>L: 01 00 03 'spiloader' → step = STEP4
    L->>L: HSMSetPMutexAndSemphre()(加锁)
    L->>U: CURRENT STEP : 4 STEP4_DOWNLOAD_FW
    loop ini 每一行 APDU
        L->>P: SendOneMessageOneShot(裸 APDU, send_len)
        L->>L: 500ms(第2行后)/10ms
        P-->>L: ReceiveOneMessage(16B)
        L->>L: memcmp(receive, compare, 2) == 90 00
    end
    L->>P: BF 46 生效 COS(不读取响应)
    L->>L: HSMClearPMutexAndSemphre + HSMHardwareDeinit
    L-->>U: return 0x00 UPGRADE_SUCCESS
```
